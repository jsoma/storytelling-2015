# models.py
# peewee
# Another popular one: SQLAlchemy

from peewee import * 

db = SqliteDatabase('schools.db')

class School(Model):
	# Define every single column
	# from the database that we
	# want to talk about
	dbn = CharField(primary_key=True)
	school_name = CharField()
	boro = CharField()
	total_students = IntegerField()

	class Meta:
		database = db
		db_table = "schools"

