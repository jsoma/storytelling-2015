from flask import Flask
from flask import render_template
from models import *

app = Flask(__name__)

@app.route('/')
def index():
	schools_count = School.select().count()
	return render_template('index.html', count=schools_count)

if __name__ == '__main__':
    app.run(debug=True)